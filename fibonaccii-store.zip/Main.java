import java.util.*;

class Main {

    static int fibDP(int n, ArrayList<Integer> dp) {
        if (n <= 1) return n;

        // if already computed, return it
        if (dp.get(n) != -1) 
            return dp.get(n);

        // compute and store
        dp.set(n, fibDP(n - 1, dp) + fibDP(n - 2, dp));
        return dp.get(n);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter number:");
        int n = sc.nextInt();

        // initialize dp array with -1
        ArrayList<Integer> dp = new ArrayList<>();
        for (int i = 0; i <= n; i++) {
            dp.add(-1);
        }

        ArrayList<Integer> result = new ArrayList<>();

        for (int i = 0; i < n; i++) {
            result.add(fibDP(i, dp));
        }

        System.out.println("Fibonacci series (DP):");
        System.out.println(result);
    }
}
