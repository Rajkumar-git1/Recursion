import java.util.*;
public class Main

{
     static void f(String curr,int m,int n,int o){
        if(curr.length()==n+m+o)
        {
            System.out.print(curr);
            return;
        }
        if(m!=0){
            f(curr+"B",m-1,n,o);
        }
          else if(n!=0){
          
            f(curr+"C",m,n-1,o);
            
        }
          else if(o!=0){
            
            f(curr+ "A",m,n,o-1);
        }
    }
	public static void main(String[] args) {
	
	f(" ",2,1,1);
	
	}
}
