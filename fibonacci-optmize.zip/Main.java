import java.util.*;

class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter number:");
        int n = sc.nextInt();

        ArrayList<Integer> arr = new ArrayList<>();

        if (n <= 0) {
            System.out.println(arr);
            return;
        }

        int a = 0, b = 1;

        arr.add(a);
        if (n > 1) arr.add(b);

        for (int i = 2; i < n; i++) {
            int c = a + b;
            arr.add(c);
            a = b;
            b = c;
        }

        System.out.println("Fibonacci series:"+arr);
        
    }
}
